/* ============================================================
   FREY v3 — ask.js
   提问箱地址：把 ASK_URL 换成你的真实问卷链接（问卷星/腾讯问卷等）。
   ============================================================ */
(function () {
  'use strict';
  var ASK_URL = 'https://www.wjx.cn/vm/example.aspx'; // ← 替换成你的提问箱地址
  var btn = document.getElementById('ask-btn');
  if (btn) btn.href = ASK_URL;
})();
