/* ============================================================
   FREY v3 — hobby.js · F1 slider + record deck
   ============================================================ */
(function () {
  'use strict';
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- F1 ---------- */
  var slider = document.getElementById('f1-slider');
  var out = document.getElementById('f1-speed');
  var car = document.getElementById('f1-car');
  var lap = document.getElementById('f1-lap');
  if (slider && out) {
    var laps = 0;
    function render() {
      var v = Number(slider.value);
      var kmh = Math.round(40 + v * 2.6);
      out.innerHTML = kmh + '<i>.</i>';
      if (car) {
        car.style.left = ((v / 100) * 78) + '%';
      }
      if (lap) {
        lap.textContent = 'LAP ' + String(Math.floor(v / 8) + 1).padStart(2, '0');
      }
    }
    slider.addEventListener('input', render);
    render();
  }

  /* ---------- record deck ---------- */
  var canvas = document.getElementById('deck-wave');
  var genresWrap = document.getElementById('deck-genres');
  var nowTitle = document.getElementById('deck-title');
  if (canvas && genresWrap) {
    var ctx = canvas.getContext('2d');
    var DPR = Math.min(2, window.devicePixelRatio || 1);
    function sizeCanvas() {
      var w = canvas.clientWidth, h = canvas.clientHeight;
      canvas.width = w * DPR; canvas.height = h * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      return { w: w, h: h };
    }

    var GENRES = {
      lofi:     { label: 'lo-fi rain',     bars: 36, amp: 0.42, speed: 0.6, a: '#0C7A70', b: '#FF4D8D' },
      ambient:  { label: 'ambient drift',  bars: 24, amp: 0.30, speed: 0.28, a: '#0C7A70', b: '#17A093' },
      jazz:     { label: 'blue note',      bars: 30, amp: 0.50, speed: 0.45, a: '#16130E', b: '#FF4D8D' },
      electro:  { label: 'midnight pulse', bars: 48, amp: 0.62, speed: 1.1,  a: '#17A093', b: '#FF4D8D' }
    };
    var current = 'lofi';
    var t = 0;

    function pickGenre(name, btn) {
      current = name;
      genresWrap.querySelectorAll('.genre').forEach(function (g) {
        g.classList.toggle('is-on', g === btn || g.dataset.genre === name);
      });
      if (nowTitle) nowTitle.textContent = GENRES[name].label;
      if (!reduced) t = 0;
    }
    genresWrap.addEventListener('click', function (e) {
      var btn = e.target.closest('.genre');
      if (btn) pickGenre(btn.dataset.genre, btn);
    });

    function draw() {
      var dim = sizeCanvas();
      var g = GENRES[current];
      ctx.clearRect(0, 0, dim.w, dim.h);
      var mid = dim.h / 2;
      var barW = dim.w / (g.bars * 2 - 1);
      for (var i = 0; i < g.bars; i++) {
        var n = Math.sin(i * 0.55 + t * g.speed) * 0.5
              + Math.sin(i * 1.7 - t * g.speed * 1.3) * 0.3
              + Math.sin(i * 3.1 + t * g.speed * 2.2) * 0.2;
        var hgt = Math.max(3, dim.h * g.amp * Math.abs(n));
        ctx.fillStyle = (i % 5 === 0) ? g.b : g.a;
        ctx.globalAlpha = 0.9;
        ctx.fillRect(i * barW * 2, mid - hgt / 2, barW, hgt);
      }
      ctx.globalAlpha = 1;
      if (!reduced) { t += 0.05; requestAnimationFrame(draw); }
    }
    draw();
    window.addEventListener('resize', function () { if (reduced) draw(); }, { passive: true });
  }
})();
