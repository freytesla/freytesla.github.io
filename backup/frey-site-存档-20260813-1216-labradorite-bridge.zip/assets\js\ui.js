﻿/* ============================================================
   FREY v2 — shared UI: loader / cursor / lenis / reveal / theme
   ============================================================ */
(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia('(pointer: fine)').matches;

  /* ---------------- Loader ---------------- */
  function initLoader() {
    var loader = document.getElementById('loader');
    if (!loader || loader.hasAttribute('data-skip')) return;
    var pctEl = loader.querySelector('.loader__pct');
    var barEl = loader.querySelector('.loader__bar i');

    // After the FREY word letters have fully risen, hold 0.5s before the curtain lifts.
    var spans = loader.querySelectorAll('.loader__word span');
    var textDone = 0;
    for (var i = 0; i < spans.length; i++) {
      var cs = window.getComputedStyle(spans[i]);
      var delay = parseFloat(cs.animationDelay) || 0;
      var durMs = (parseFloat(cs.animationDuration) || 0) * 1000;
      textDone = Math.max(textDone, delay * 1000 + durMs);
    }
    if (!textDone) textDone = 1160; // fallback: last letter = 0.46s delay + 0.7s anim
    var hold = 100; // hold 0.1s after the text is fully shown
    var dur = textDone + hold;

    var t0 = performance.now();
    function frame(now) {
      var p = Math.min(1, (now - t0) / dur);
      var eased = 1 - Math.pow(1 - p, 3);
      var v = Math.round(eased * 100);
      if (pctEl) pctEl.textContent = String(v).padStart(3, '0');
      if (barEl) barEl.style.transform = 'scaleX(' + eased + ')';
      loader.style.setProperty('--lp', eased);
      if (p < 1) { requestAnimationFrame(frame); }
      else {
        loader.classList.add('done');
        setTimeout(function () { loader.remove(); }, 950);
        document.body.classList.add('page-in');
      }
    }
    requestAnimationFrame(frame);
  }

  /* ---------------- Custom cursor ---------------- */
  function initCursor() {
    if (!finePointer) return;
    document.body.classList.add('has-cursor');
    var dot = document.getElementById('cur-dot');
    var ring = document.getElementById('cur-ring');
    if (!dot || !ring) return;
    var mx = innerWidth / 2, my = innerHeight / 2, rx = mx, ry = my;
    var hovering = false;
    window.addEventListener('mousemove', function (e) {
      mx = e.clientX; my = e.clientY;
      dot.style.transform = 'translate3d(' + mx + 'px,' + my + 'px,0)';
    }, { passive: true });
    (function loop() {
      rx += (mx - rx) * 0.14; ry += (my - ry) * 0.14;
      ring.style.transform = 'translate3d(' + rx + 'px,' + ry + 'px,0)';
      requestAnimationFrame(loop);
    })();
    document.addEventListener('mouseover', function (e) {
      var t = e.target.closest('a,button,.btn,[data-hover],.card,.tile,.ticket,.g-item,canvas');
      if (t && !hovering) { hovering = true; ring.classList.add('is-hover'); }
    });
    document.addEventListener('mouseout', function (e) {
      var t = e.target.closest('a,button,.btn,[data-hover],.card,.tile,.ticket,.g-item,canvas');
      if (t && hovering) { hovering = false; ring.classList.remove('is-hover'); }
    });
    window.addEventListener('mousedown', function () { ring.classList.add('is-down'); });
    window.addEventListener('mouseup', function () { ring.classList.remove('is-down'); });
  }

  /* ---------------- Lenis smooth scroll ---------------- */
  function initLenis() {
    if (reduced || !window.Lenis) return;
    var lenis = new Lenis({ duration: 1.15, smoothWheel: true });
    function raf(time) { lenis.raf(time); requestAnimationFrame(raf); }
    requestAnimationFrame(raf);
    window.lenis = lenis;
    document.querySelectorAll('[data-to-top]').forEach(function (el) {
      el.addEventListener('click', function (e) { e.preventDefault(); lenis.scrollTo(0, { duration: 1.4 }); });
    });
  }

  /* ---------------- In-page anchors: nudge so section heading sits under the nav ---------------- */
  function initAnchorNudge() {
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var href = a.getAttribute('href');
        if (!href || href === '#') return;
        var el = document.querySelector(href);
        if (!el) return;
        e.preventDefault();
        var head = document.querySelector('.site-head');
        var hh = head ? head.getBoundingClientRect().height : 92;
        var t = el.querySelector('.sec-head, h1, h2, h3, .ask-title') || el;
        var cur = window.scrollY;
        var dy = 0;   // account for un-revealed [data-reveal] translateY so the goal is layout-accurate
        if (window.DOMMatrix && t.classList && !t.classList.contains('is-in')) {
          var tr = getComputedStyle(t).transform;
          if (tr && tr !== 'none') dy = new DOMMatrix(tr).f;
        }
        var absTop = t.getBoundingClientRect().top + cur - dy;
        var goal = Math.max(0, absTop - hh - 8);   // land the heading ~8px under the fixed nav
        if (window.lenis) {
          window.lenis.scrollTo(goal);
        } else {
          window.scrollTo(0, goal);
        }
      });
    });
  }

  /* ---------------- Marquee: damped speed on hover ---------------- */
  function initMarquee() {
    document.querySelectorAll('.marquee').forEach(function (row) {
      var track = row.querySelector('.marquee__track');
      if (!track || track.dataset.marquee === '1') return;
      track.dataset.marquee = '1';
      track.style.animation = 'none';      // JS drives the loop; CSS anim stays as no-JS fallback
      if (reduced) return;                 // reduced motion -> static
      var base = parseFloat(row.dataset.speed) || 30;   // px/sec
      var slow = parseFloat(row.dataset.slow) || 0.15;  // hover speed ratio
      var speed = base, target = base, x = 0, last = performance.now();
      function half() { return track.scrollWidth / 2; }
      function step(now) {
        var dt = Math.min((now - last) / 1000, 0.05);
        last = now;
        speed += (target - speed) * Math.min(1, dt * 3);   // damping
        x -= speed * dt;
        var h = half();
        if (h > 0 && x <= -h) x += h;      // seamless wrap (2 identical halves)
        track.style.transform = 'translateX(' + x.toFixed(2) + 'px)';
        requestAnimationFrame(step);
      }
      row.addEventListener('mouseenter', function () { target = base * slow; });
      row.addEventListener('mouseleave', function () { target = base; });
      requestAnimationFrame(step);
    });
  }

  /* ---------------- Reveal on scroll ---------------- */
  function initReveal() {
    var els = document.querySelectorAll('[data-reveal]');
    if (!('IntersectionObserver' in window) || reduced) {
      els.forEach(function (el) { el.classList.add('is-in'); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    els.forEach(function (el) { io.observe(el); });
  }

  /* ---------------- Theme (header color follows section) ---------------- */
  function initTheme() {
    var body = document.body;
    var fixed = body.getAttribute('data-theme'); // pages with fixed theme
    if (fixed) return;
    /* theme follows the section behind the fixed header (probe below the header),
       so the header text never turns invisible against a mismatched background */
    function pick() {
      if (!document.elementsFromPoint) return;
      var list = document.elementsFromPoint(innerWidth / 2, 55);
      for (var i = 0; i < list.length; i++) {
        var el = list[i];
        if (!el || !el.closest) continue;
        var sec = el.closest('[data-theme]');
        if (sec) { body.setAttribute('data-theme', sec.getAttribute('data-theme')); return; }
      }
    }
    window.addEventListener('scroll', pick, { passive: true });
    window.addEventListener('resize', pick);
    pick();
  }

  /* ---------------- Mobile menu ---------------- */
  function initMobileMenu() {
    var burger = document.querySelector('.head-burger');
    var menu = document.querySelector('.head-mobile');
    if (!burger || !menu) return;
    burger.addEventListener('click', function () {
      var open = menu.classList.toggle('open');
      burger.classList.toggle('open', open);
      document.body.classList.toggle('menu-open', open);
      document.body.style.overflow = open ? 'hidden' : '';
    });
    menu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        burger.classList.remove('open');
        menu.classList.remove('open');
        document.body.classList.remove('menu-open');
        document.body.style.overflow = '';
      });
    });
  }

  /* ---------------- Page transition ---------------- */
  /* ---------------- Page transition ---------------- */
  /* ---------------- Chapter HUD (fixed section indicator) ---------------- */
  function initChapterHud() {
    var hud = document.getElementById('chapter-hud');
    if (!hud) return;
    var num = hud.querySelector('.chapter-hud__num');
    var name = hud.querySelector('.chapter-hud__name');
    var prog = hud.querySelector('#hud-prog');
    var chapters = Array.prototype.slice.call(document.querySelectorAll('[data-chapter]'));
    if (!chapters.length) return;
    var ticking = false;
    function setActive(active) {
      var total = ('0' + chapters.length).slice(-2);
      if (num) num.textContent = active.getAttribute('data-chapter') + ' / ' + total;
      if (name) name.textContent = active.getAttribute('data-chapter-name') || '';
    }
    function updateProg() {
      var vh = window.innerHeight || 1;
      var max = document.documentElement.scrollHeight - vh;
      var p = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
      if (prog) prog.style.transform = 'scaleY(' + p.toFixed(3) + ')';
    }
    function update() {
      ticking = false;
      var vh = window.innerHeight || 1;
      var sy = window.scrollY;
      var max = document.documentElement.scrollHeight - vh;
      var nearBottom = max > 0 && sy >= max - vh * 0.35;

      /* normal flow detection; the sticky footer always sits in the
         viewport, so only count it once we are truly near the end */
      /* while the choose page is still wiping in over the photo wall,
         keep the previous chapter active until the wipe completes */
      var wipeSt = (window.ScrollTrigger && window.ScrollTrigger.getById)
        ? window.ScrollTrigger.getById('choose-wipe') : null;
      var chooseChapter = document.getElementById('choose');
      var wipeActive = !!wipeSt && wipeSt.progress < 1;
      var last = chapters[chapters.length - 1];
      var active = chapters[0];
      for (var i = 0; i < chapters.length; i++) {
        if (wipeActive && chapters[i] === chooseChapter) continue;
        if (chapters[i] === last && !nearBottom) continue;
        if (chapters[i].getBoundingClientRect().top <= vh * 0.5) active = chapters[i];
      }
      setActive(active);
      updateProg();
    }
    function request() {
      if (!ticking) { ticking = true; requestAnimationFrame(update); }
    }
    window.addEventListener('scroll', request, { passive: true });
    window.addEventListener('resize', request);
    update();
  }

  function initTransitions() {
    var supportsView = 'startViewTransition' in document;
    document.addEventListener('click', function (e) {
      var a = e.target.closest('a[href]');
      if (!a) return;
      var href = a.getAttribute('href');
      if (!href || href.charAt(0) === '#' || href.indexOf('http') === 0 || a.target === '_blank' || a.hasAttribute('download')) return;
      if (href === location.pathname.split('/').pop() || href === location.pathname) return;
      e.preventDefault();
      if (supportsView) {
        document.startViewTransition(function () { location.href = href; });
      } else {
        document.documentElement.classList.add('is-leaving');
        setTimeout(function () { location.href = href; }, 380);
      }
    });
  }

  /* ---------------- Boot ---------------- */
  document.addEventListener('DOMContentLoaded', function () {
    initLoader();
    initCursor();
    initLenis();
    initMarquee();
    initAnchorNudge();
    initReveal();
    initTheme();
    initChapterHud();
    initMobileMenu();
    initTransitions();
  });
})();







