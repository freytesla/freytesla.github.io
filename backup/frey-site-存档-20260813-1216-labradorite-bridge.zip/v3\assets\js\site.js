/* ============================================================
   FREY v3 — site.js · shared interactions
   menu · reveals · progress · marquee · year
   ============================================================ */
(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.documentElement.classList.add('js');

  /* ---------- menu ---------- */
  var btn = document.getElementById('menu-btn');
  var menu = document.getElementById('menu');
  if (btn && menu) {
    function closeMenu() {
      btn.classList.remove('is-open');
      menu.classList.remove('is-open');
      btn.setAttribute('aria-expanded', 'false');
      menu.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
    function toggleMenu() {
      var open = menu.classList.contains('is-open');
      if (open) { closeMenu(); return; }
      btn.classList.add('is-open');
      menu.classList.add('is-open');
      btn.setAttribute('aria-expanded', 'true');
      menu.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    }
    btn.addEventListener('click', toggleMenu);
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) closeMenu();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeMenu();
    });
    // restore scroll state on bfcache back/forward
    window.addEventListener('pageshow', function () {
      document.body.style.overflow = '';
    });
  }

  /* ---------- reveals ---------- */
  var revealEls = document.querySelectorAll('.rv, .wipe');
  if ('IntersectionObserver' in window && !reduced) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add('in');
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0, rootMargin: '0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in'); });
  }


  /* fallback: reveal anything that enters the viewport on scroll,
     so fast scrolling / anchor jumps never leave content hidden */
  var pendingEls = Array.from(document.querySelectorAll('.rv, .wipe'));
  function revealInView() {
    var vh = window.innerHeight || document.documentElement.clientHeight;
    pendingEls = pendingEls.filter(function (el) {
      var r = el.getBoundingClientRect();
      if (r.top < vh && r.bottom > 0) {
        el.classList.add('in');
        return false;
      }
      return true;
    });
    if (pendingEls.length === 0) {
      window.removeEventListener('scroll', revealInView);
      window.removeEventListener('resize', revealInView);
    }
  }
  window.addEventListener('scroll', revealInView, { passive: true });
  window.addEventListener('resize', revealInView, { passive: true });
  revealInView();

  /* ---------- scroll progress ---------- */
  var prog = document.getElementById('progress');
  if (prog) {
    var bar = prog.querySelector('i');
    var ticking = false;
    function update() {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      var p = max > 0 ? (h.scrollTop || window.scrollY || 0) / max : 0;
      bar.style.transform = 'scaleX(' + Math.min(1, Math.max(0, p)) + ')';
      ticking = false;
    }
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; requestAnimationFrame(update); }
    }, { passive: true });
    update();
  }

  /* ---------- marquee: ensure the track is at least 2x viewport ---------- */
  document.querySelectorAll('.marquee').forEach(function (mq) {
    var track = mq.querySelector('.marquee__track');
    if (!track) return;
    var fill = function () {
      var copy = track.cloneNode(true);
      while (track.scrollWidth < mq.clientWidth * 2) {
        track.appendChild(copy.cloneNode(true));
      }
    };
    fill();
    window.addEventListener('resize', fill, { passive: true });
  });

  /* ---------- year ---------- */
  document.querySelectorAll('[data-year]').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });
})();
