# FREY v3 — The First Solo Show

Frey 个人网站的 **v3 视觉重构版**，全新设计语言，与 v2 主站（仓库根目录）并存，**不覆盖旧版**。
v2 主站保持在仓库根目录；本目录为 v3 独立版本，可整体替换或单独部署（如 GitHub Pages 的 `/v3/` 路径）。

## 设计概念

> 整个网站是一场「首场个人演出」——海报 + 节目单。演出分幕：ACT I 我是谁 / ACT II 作品 / ACT III 爱好 / ENCORE 来信。

- **签名单品**：套版错位（misregistration）——标题的粉/绿错位层在悬停时「校正对齐」；票根打孔分隔线；NOW SHOWING 跑马灯。
- **配色**（risograph 三色油墨 + 纸 + 墨）：
  | Token | 值 | 用途 |
  | --- | --- | --- |
  | `--paper` | `#F1EDE2` | 纸底 |
  | `--ink` | `#16130E` | 墨黑 |
  | `--mars` | `#0C7A70` | 马尔斯绿（延续 v2 身份色） |
  | `--pink` | `#FF4D8D` | 荧光粉（错位油墨） |
- **字体**：Bricolage Grotesque（英文海报标题）/ Noto Serif SC 900（中文标题）/ Archivo + Noto Sans SC（正文）/ Space Mono（标签、数据）。

## 本地预览

```powershell
cd C:\Users\Administrator\Desktop\frey.github.io\v3
python -m http.server 8123
# 浏览器打开 http://localhost:8123
```

> 仅 Google Fonts 需要联网；HTML/CSS/JS 无 ES Module 依赖，双击 HTML 也能跑（字体回退到系统字体）。

## 页面结构

| 文件 | 内容 |
| --- | --- |
| `index.html` | 海报 Hero（FREY 错位大字 + 芙蕾色块 + 旋转印章 + ADMIT ONE 票带）→ ACT I 关于（宣言 + 深圳—广州—佛山线路图）→ ACT II 作品预览 → ACT III 曲目单 → ENCORE 来信 |
| `work.html` | 6 个工程作品卡 + 6 张「版画」绘画 |
| `hobby.html` | F1 速度滑块 / 音乐剧票根 / 唱片机（实时波形）/ 喜欢的人物 |
| `ask.html` | 提问箱 + 联系方式 |
| `404.html` | 故障风「此场次不存在」 |

## 需要替换的内容（代码里都有注释标记）

1. **提问箱地址** — `assets/js/ask.js` 里的 `ASK_URL`（问卷星/腾讯问卷等）
2. **联系方式 / 社交链接** — 各页 `footer` 与 `ask.html`（邮箱/GitHub/Bilibili/Instagram）
3. **作品与画作** — `work.html` 里 6 张工程卡与 6 张画（SVG 占位，可换图片）
4. **票根信息** — `hobby.html` 的剧名 / 日期 / 座位
5. **喜欢的人物** — `hobby.html` #people 里的 4 张人物卡（示例人物）
6. **线路图** — `index.html` ACT I 的 `transit` SVG（深圳 / 广州 / 佛山，可改城市）

## 技术要点

- 纯 HTML + CSS + 原生 JS，无构建步骤；动效：IntersectionObserver + 滚动兜底揭示、跑马灯、错位校正、旋转印章（内层旋转避免撑出滚动条）
- 响应式：1440 / 820 / 390 三档均无横向溢出；`prefers-reduced-motion` 降级
- 无障碍：菜单 `aria-expanded` / `aria-hidden`、键盘焦点样式、无 JS 时内容默认可见（`<noscript>` 兜底）
